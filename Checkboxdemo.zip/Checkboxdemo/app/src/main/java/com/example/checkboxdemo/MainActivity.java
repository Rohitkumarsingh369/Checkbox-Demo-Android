package com.example.checkboxdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    CheckBox checkbox1,checkbox2,checkbox3;
    Button submitbutton;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkbox1=(CheckBox)findViewById(R.id.checkBox);
        checkbox2=(CheckBox)findViewById(R.id.checkBox2);
        checkbox3=(CheckBox)findViewById(R.id.checkBox3);
        submitbutton=(Button)findViewById(R.id.button);
        textView=(TextView)findViewById(R.id.textView);
    }
    public void onClick(View view){
        if(checkbox1.isChecked()==true && checkbox2.isChecked()==true && checkbox3.isChecked()==true){
            textView.setText("You like all fruits !");
        }
        else if(checkbox1.isChecked()==true && checkbox2.isChecked()==true ){
            textView.setText("You like Banana and Apple !");
        }
        else if(checkbox1.isChecked()==true && checkbox3.isChecked()==true ){
            textView.setText("You like Banana and Orange !");
        }
        else if(checkbox2.isChecked()==true && checkbox3.isChecked()==true ){
            textView.setText("You like Apple and Orange !");
        }
        else if(checkbox1.isChecked()==true  ){
            textView.setText("You like Banana !");
        }
        else if(checkbox2.isChecked()==true  ){
            textView.setText("You like Apple !");
        }
        else if(checkbox3.isChecked()==true  ){
            textView.setText("You like Orange !");
        }
        else{
            textView.setText("You don't  like these fruits ?");
            textView.setText("Rohit");
        }

    }
}